# JSDoc to .d.ts + Markdown Live RAG Pipeline

A continuous pipeline that watches JSDoc-annotated JavaScript/TypeScript source code, compiles it into TypeScript declaration files (`.d.ts`), generates structured Markdown documentation, and synchronizes a local Retrieval-Augmented Generation (RAG) vector index in real time.

```
                  ┌────────────────┐
                  │ JSDoc JS / TS  │
                  └───────┬────────┘
                          │ (chokidar watcher)
            ┌─────────────┴─────────────┐
            ▼                           ▼
    ┌───────────────┐           ┌───────────────┐
    │ dist/types/   │           │  dist/docs/   │
    │    *.d.ts     │           │     *.md      │
    └───────┬───────┘           └───────┬───────┘
            │                           │
            └─────────────┬─────────────┘
                          ▼
             ┌─────────────────────────┐
             │   Semantic Chunker      │
             │ Symbol & Type Preserved │
             └────────────┬────────────┘
                          ▼
             ┌─────────────────────────┐
             │  Local Embeddings       │
             │ Xenova/all-MiniLM-L6-v2 │
             └────────────┬────────────┘
                          ▼
             ┌─────────────────────────┐
             │  RAG Vector Store       │
             │ Real-time Sync & Query  │
             └─────────────────────────┘
```

## Features

- **JSDoc to `.d.ts` Compilation**: Emits accurate TypeScript declaration files directly from JSDoc comments (`@typedef`, `@param`, `@returns`, etc.) using TypeScript Compiler API.
- **Structured Markdown Generator**: Generates RAG-friendly documentation with symbol signatures, parameters tables, descriptions, `@example` snippets, and `@deprecated` notices.
- **Semantic Symbol Chunking**: Chunks `.d.ts` declarations and Markdown files by exported symbols, keeping context intact.
- **Local & Offline RAG Embeddings**: Dense 384-dimensional vector embeddings generated locally via `@xenova/transformers` (`all-MiniLM-L6-v2`) with zero external API key requirements.
- **Continuous Watcher**: Uses `chokidar` with debounced incremental updates to compile, generate docs, and update the vector store instantly on save.
- **CLI & Interactive REPL**: Query APIs, types, and documentation from the terminal or chat with your codebase.

---

## Quick Start

### 1. Build and Index
Compile all JSDoc source files into `.d.ts`, generate Markdown docs, and build the RAG index:
```bash
npm run build
```

### 2. Live Watcher Mode
Start the continuous watcher to keep `.d.ts`, Markdown, and the RAG index automatically synchronized on file changes:
```bash
npm run watch
```
Options:
- `-s, --src <dir>`: Source directory (default: `examples`)
- `-t, --types <dir>`: Output directory for `.d.ts` (default: `dist/types`)
- `-d, --docs <dir>`: Output directory for Markdown (default: `dist/docs`)
- `--debounce <ms>`: Debounce window in ms (default: `250`)

### 3. Query the RAG Engine
Search for functions, types, and usage guides using natural language:
```bash
npm run query -- "How to authenticate a user?"
npm run query -- "Calculate distance between two coordinates"
npm run query -- "2D matrix multiplication and determinant"
```

### 4. Interactive RAG REPL Shell
Launch an interactive question-answering shell:
```bash
npm run rag
```

### 5. Run Verification Tests
Run automated test suite verifying compilation, markdown generation, vector indexing, query retrieval, and incremental file synchronization:
```bash
npm test
```

---

## Project Structure

```
├── examples/                      # Example JSDoc source files
│   ├── mathUtils.js              # Geometry, 2D matrix, lerp
│   └── userService.js            # User authentication, typedefs, sessions
├── dist/
│   ├── types/                    # Emitted .d.ts files
│   └── docs/                     # Emitted Markdown documentation
├── src/
│   ├── compiler/
│   │   ├── dtsGenerator.ts       # TypeScript Compiler API declaration generator
│   │   └── markdownGenerator.ts  # AST parser & structured Markdown generator
│   ├── rag/
│   │   ├── chunker.ts            # Semantic symbol-level chunker
│   │   ├── embeddings.ts         # Local Xenova embedding service
│   │   ├── vectorStore.ts        # Persistent vector store with hybrid search
│   │   └── queryEngine.ts        # RAG query synthesis with citations
│   ├── watcher/
│   │   └── index.ts              # Chokidar live file watcher
│   ├── pipeline.ts               # Unified compilation & synchronization pipeline
│   └── cli.ts                    # CLI commands: build, watch, query, repl
└── test/
    └── pipeline.test.ts          # End-to-end verification test suite
```
